This is a website containing part 1 of the final project. Please open the index.html to view our works. Thank you.

-Team 6, Morning Section.